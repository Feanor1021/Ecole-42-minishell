/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_runcommand.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:14:29 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:14:38 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include "minishell.h"
#include "42-Libft/libft.h"

static void	checkerrors(t_command *cmd, char *path)
{
	if (ft_filexists(path))
	{
		ft_puterrln("is a directory", cmd->command);
		g_mini->return_code = 126;
	}
	else
	{
		g_mini->return_code = 127;
		ft_puterrln("No such file or directory", cmd->command);
	}
}

char	*ft_path_controler(t_command *cmd, char *cmdpath)
{
	if (ft_getenvindex("PATH") != -1 || cmd->command[0] == '/')
		return (cmdpath = ft_findinpath(cmd->command));
	return (NULL);
}

static int	execprocess(t_command *cmd)
{
	char	*cmdpath;
	pid_t	pid;

	cmdpath = NULL;
	if (!cmd->command)
	{
		ft_open_reds(cmd);
		return (-1);
	}
	cmdpath = ft_path_controler(cmd, cmdpath);
	pid = -1;
	if (cmdpath)
	{
		if (ft_isfile(cmdpath))
			pid = ft_initprocess(cmd, cmdpath);
		else
			checkerrors(cmd, cmdpath);
	}
	else
	{
		ft_puterrln("command not found", cmd->command);
		g_mini->return_code = 127;
	}
	free(cmdpath);
	return (pid);
}

int	ft_runcommand(t_command *cmd)
{
	pid_t	pid;

	ft_pars_quote(cmd);
	if (ft_isbuiltin(cmd->command))
		pid = ft_initbuiltin(cmd);
	else if (!cmd->command)
		pid = ft_initredirects(cmd);
	else
		pid = execprocess(cmd);
	return (pid);
}
