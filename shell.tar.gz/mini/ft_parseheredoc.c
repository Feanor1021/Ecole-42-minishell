/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parseheredoc.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:12:47 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:12:49 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

int	ft_parseheredoc(t_command *cmd, t_token **tokens, int *i)
{
	(*i)++;
	if (tokens[*i] && tokens[*i]->type == WORD)
	{
		ft_addarr_str(&(cmd->heredocsteps), ft_strdup(tokens[*i]->data));
		return (1);
	}
	ft_syntaxerror(tokens[*i]);
	return (0);
}
