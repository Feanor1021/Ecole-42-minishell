/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_insertarr.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:10:26 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:10:29 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "minishell.h"
#include "42-Libft/libft.h"

void	ft_insertarr(void ***arr, void *new, int index)
{
	void	**newarr;
	int		i;
	int		k;

	newarr = ft_calloc(sizeof(void *), ft_arrlen((void **)*arr) + 2);
	i = 0;
	k = 0;
	while (*arr && (*arr)[k])
	{
		if (k == index)
			newarr[i++] = new;
		newarr[i++] = (*arr)[k];
		k++;
	}
	free(*arr);
	*arr = newarr;
}
