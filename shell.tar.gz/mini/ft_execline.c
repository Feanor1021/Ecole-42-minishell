/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_execline.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:05:59 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 21:06:38 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <stdlib.h>

void	ft_execline(char *input)
{
	t_token		**tokens;
	t_pipeline	**pipelines;

	tokens = ft_gettokens(input);
	pipelines = NULL;
	if (tokens)
	{
		pipelines = ft_parsepipelines(tokens, 0, ft_arrlen((void **)tokens));
		if (pipelines)
		{
			ft_runpipelines(pipelines);
			ft_freearr_pipeline(pipelines);
		}
		ft_freearr_token(tokens);
	}
}
