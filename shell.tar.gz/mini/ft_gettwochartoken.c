/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_gettwochartoken.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:09:17 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:09:19 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "minishell.h"
#include "42-Libft/libft.h"

t_token	*ft_gettwochartoken(char *str, int *i, enum e_tokentype type, char chr)
{
	char	schr[3];

	(*i)++;
	if (str[*i] == chr)
	{
		schr[0] = chr;
		schr[1] = chr;
		schr[2] = 0;
		(*i)++;
		return (ft_createtoken(ft_strdup(schr), type));
	}
	return (NULL);
}
