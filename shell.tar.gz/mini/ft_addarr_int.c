/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_addarr_int.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:02:59 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:03:03 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "42-Libft/libft.h"

void	ft_addarr_int(int **arr, int len, int new)
{
	int	*newarr;

	newarr = ft_calloc(sizeof(int), len + 1);
	if (*arr)
		ft_memcpy(newarr, *arr, sizeof(int) * len);
	newarr[len] = new;
	free(*arr);
	*arr = newarr;
}
