/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_export.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:06:11 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:06:13 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "minishell.h"
#include "42-Libft/libft.h"

static void	set_reset(char *s)
{
	char	*key;
	char	*value;

	if (!ft_strchr(s, '='))
	{
		ft_setenv(s, 0);
		return ;
	}
	value = ft_get_value(s);
	key = ft_get_key(s);
	if (!value)
	{
		ft_setenv(key, "");
		return ;
	}
	ft_setenv(key, value);
}

int	ft_export(t_command *command)
{
	int		i;

	i = 0;
	if (!command->arguments[1])
		ft_onlyexport(command);
	else
	{
		while (command->arguments[++i])
		{
			if (ft_env_check(command->arguments[i]))
				set_reset(command->arguments[i]);
			else
			{
				ft_putstr_fd("bash: export: '", 2);
				ft_putstr_fd(command->arguments[i], 2);
				ft_putendl_fd("':not a valid identifier", 2);
				return (1);
			}
		}
	}
	return (0);
}
