/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parseredinput.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:13:04 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:13:06 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

int	ft_parseredinput(t_command *cmd, t_token **tokens, int *i)
{
	t_stream	*stream;

	(*i)++;
	if (tokens[*i] && tokens[*i]->type == WORD)
	{
		stream = ft_calloc(sizeof(t_stream), 1);
		stream->type = STREAM_IN;
		stream->path = ft_strdup(tokens[*i]->data);
		ft_addarr_stream(&(cmd->redirections), stream);
		return (1);
	}
	ft_syntaxerror(tokens[*i]);
	return (0);
}
