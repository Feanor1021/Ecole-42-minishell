/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_closepipes.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:04:08 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:04:10 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include "minishell.h"

void	ft_closepipes(void)
{
	int	i;

	i = 0;
	while (i < g_mini->pipecount)
		close(g_mini->openedpipes[i++]);
	free(g_mini->openedpipes);
	g_mini->pipecount = 0;
	g_mini->openedpipes = NULL;
}
