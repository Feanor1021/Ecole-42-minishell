/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_onlyexport.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:11:35 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/02 00:21:30 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "minishell.h"
#include "42-Libft/libft.h"

static void	sort(char **arr)
{
	char	*tmp;
	int		i;
	int		j;

	i = 0;
	while (arr[i])
	{
		j = i + 1;
		while (arr[j])
		{
			if (arr[i][0] > arr[j][0])
			{
				tmp = arr[i];
				arr[i] = arr[j];
				arr[j] = tmp;
			}
			j++;
		}
		i++;
	}
}

static char	*double_quotes(char *s)
{
	char	*buff;
	char	*buff2;

	buff = ft_strjoin("\"", s);
	free(s);
	buff2 = ft_strjoin(buff, "\"");
	free(buff);
	return (buff2);
}

static void	__onlyexport(char ***env, t_command *command, int i)
{
	sort(*env);
	i = -1;
	while ((*env)[++i])
	{
		ft_putstr_fd("declare -x", command->out);
		ft_putendl_fd((*env)[i], command->out);
	}
	ft_freearr_str(*env);
}

void	ft_onlyexport(t_command *command)
{
	int		i;
	char	*key;
	char	*value;
	char	**env;

	env = ft_calloc(sizeof(char *), ft_arrlen((void **)g_mini->env) + 1);
	i = -1;
	while (g_mini->env[++i])
	{
		if (ft_strchr(g_mini->env[i], '='))
		{
			key = ft_get_key(g_mini->env[i]);
			value = ft_get_value(g_mini->env[i]);
			value = double_quotes(value);
			ft_strappend(&key, "=");
			ft_strappend(&key, value);
			free(value);
			env[i] = key;
		}
		else
			env[i] = ft_strdup(g_mini->env[i]);
	}
	__onlyexport(&env, command, -1);
}
