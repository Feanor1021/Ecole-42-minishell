/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strappend.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:15:24 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:15:27 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "42-Libft/libft.h"

void	ft_strappend(char **str, char *appendstr)
{
	char	*old;

	if (!appendstr)
		return ;
	old = *str;
	*str = ft_strjoin(*str, appendstr);
	free(old);
}
