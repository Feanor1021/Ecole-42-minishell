/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_initredirects.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:10:07 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:10:11 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

int	ft_initredirects(t_command *cmd)
{
	if (ft_open_reds(cmd))
	{
		g_mini->return_code = 0;
		return (-1);
	}
	g_mini->return_code = 1;
	return (0);
}
