/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_getenv.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:08:07 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:08:09 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <stdlib.h>

char	*ft_getenv(char *name)
{
	int		i;
	int		variable_index;
	char	*var;

	variable_index = ft_getenvindex(name);
	if (variable_index == -1)
		return (NULL);
	var = g_mini->env[variable_index];
	i = 0;
	while (var[i] && var[i] != '=')
		i++;
	if (var[i])
		i++;
	return (var + i);
}
