/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isfile.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:10:54 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:10:56 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <sys/types.h>
#include <sys/stat.h>

int	ft_isfile(char *path)
{
	struct stat	path_stat;

	stat(path, &path_stat);
	return ((((path_stat.st_mode) & S_IFMT) == S_IFREG));
}
