/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_get_key.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:07:54 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:07:56 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "42-Libft/libft.h"
#include "minishell.h"

char	*ft_get_key(char *s)
{
	int		len;
	char	*key;

	len = ft_strlenchr(s, '=');
	key = ft_substr(s, 0, len);
	return (key);
}
