/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_connectpipes.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:04:25 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:04:30 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include "minishell.h"

static void	connect_pipe(t_command **cmds, int i, int *p)
{
	if (cmds[i + 1] && i - 1 >= 0)
	{
		ft_addarr_int(&(g_mini->openedpipes), g_mini->pipecount++, p[0]);
		cmds[i]->in = p[0];
		pipe(p);
		cmds[i]->out = p[1];
		ft_addarr_int(&(g_mini->openedpipes), g_mini->pipecount++, p[1]);
	}
	else if (i == 0 && cmds[i + 1])
	{
		pipe(p);
		ft_addarr_int(&(g_mini->openedpipes), g_mini->pipecount++, p[1]);
		cmds[i]->out = p[1];
	}
	else if (!cmds[i + 1])
	{
		cmds[i]->in = p[0];
		ft_addarr_int(&(g_mini->openedpipes), g_mini->pipecount++, p[0]);
	}
}

void	ft_connectpipes(t_command **cmds)
{
	int	p[2];
	int	i;
	int	len;

	i = -1;
	len = ft_arrlen((void **)cmds);
	if (len == 1)
		return ;
	while (++i < len)
		connect_pipe(cmds, i, p);
	i = -1;
}
