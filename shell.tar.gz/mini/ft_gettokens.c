/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_gettokens.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:09:10 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:09:13 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "minishell.h"
#include "42-Libft/libft.h"

t_token	**ft_gettokens(char *str)
{
	t_token	**tokens;
	t_token	*token;

	tokens = NULL;
	while (1)
	{
		token = ft_getnexttoken(str);
		if (!token)
			break ;
		ft_addarr_token(&tokens, token);
	}
	return (tokens);
}
