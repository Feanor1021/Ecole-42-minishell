/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_first_star.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:06:44 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:26:24 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

int	ft_first_star(t_command *command)
{
	char	**new_command;
	char	**tmp;

	tmp = command->arguments;
	new_command = ft_calloc(sizeof(char *), 3);
	new_command[0] = "";
	new_command[1] = command->arguments[0];
	command->arguments = new_command;
	tmp[0] = command->arguments[1];
	free(command->arguments);
	command->arguments = tmp;
	free(command->command);
	command->command = ft_strdup(command->arguments[0]);
	return (0);
}
