/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_signalhandler.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:15:09 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:15:12 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <readline/readline.h>
#include <signal.h>
#include "minishell.h"
#include "42-Libft/libft.h"

void	ft_signalhandler(int sig)
{
	(void)sig;
	if (g_mini->intflag)
	{
		printf("\n");
		g_mini->intflag = 0;
		return ;
	}
	g_mini->return_code = 1;
	rl_replace_line("", 0);
	printf("\n");
	rl_on_new_line();
	rl_redisplay();
}
