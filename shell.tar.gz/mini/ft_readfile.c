/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_readfile.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:13:59 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:14:02 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "minishell.h"
#include "42-Libft/libft.h"

char	*ft_readfile(char *path)
{
	char	*ret;
	char	buff[1024];
	int		fd;
	int		readed;

	ret = NULL;
	fd = open(path, O_RDONLY);
	while (1)
	{
		readed = read(fd, buff, sizeof(buff));
		if (readed == 0 || readed == -1)
			break ;
		buff[readed] = 0;
		ft_strappend(&ret, buff);
	}
	close(fd);
	return (ret);
}
