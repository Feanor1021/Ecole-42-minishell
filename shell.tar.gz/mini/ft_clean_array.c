/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_clean_array.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:03:54 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:03:57 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include <stdio.h>
#include "42-Libft/libft.h"

static void	remove_nullstring(t_command *cmd, int total_zero)
{
	int		i;
	int		j;
	int		len;
	char	**tmp;

	len = ft_arrlen((void **)cmd->arguments);
	tmp = ft_calloc(sizeof(char *), len - total_zero + 1);
	i = -1;
	j = 0;
	while (cmd->arguments && cmd->arguments[++i])
	{
		if (ft_strlen(cmd->arguments[i]) == 0)
		{
			j++;
			free(cmd->arguments[i]);
		}
		else
			tmp[i - j] = cmd->arguments[i];
	}
	free(cmd->arguments);
	cmd->arguments = tmp;
}

void	ft_clean_array(t_command *cmd)
{
	int		i;
	int		total_zero;

	i = -1;
	total_zero = 0;
	while (cmd->arguments && cmd->arguments[++i])
	{
		if (ft_strlen(cmd->arguments[i]) == 0)
			total_zero++;
	}
	remove_nullstring(cmd, total_zero);
}
