/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_extendarr.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:06:18 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:06:20 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"
#include <stdlib.h>

void	ft_extendarr(void ***arr, void **otherarr)
{
	void	**newarr;
	int		i;
	int		k;

	newarr = ft_calloc(sizeof(void *), \
					ft_arrlen(*arr) + ft_arrlen(otherarr) + 1);
	i = 0;
	k = 0;
	while ((*arr)[k])
		newarr[i++] = (*arr)[k++];
	k = 0;
	while (otherarr[k])
		newarr[i++] = otherarr[k++];
	free(*arr);
	*arr = newarr;
}
