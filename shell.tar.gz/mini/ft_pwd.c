/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pwd.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:13:53 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:13:55 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "minishell.h"
#include "42-Libft/libft.h"

int	ft_pwd(t_command *cmd)
{
	char	buffer[4096];

	getcwd(buffer, 4096);
	ft_putendl_fd(buffer, cmd->out);
	return (0);
}
