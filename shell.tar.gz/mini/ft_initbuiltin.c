/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_initbuiltin.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:09:43 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:09:45 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "minishell.h"
#include "42-Libft/libft.h"

int	ft_initbuiltin(t_command *cmd)
{
	pid_t	pid;

	if (cmd->in != 0 || cmd->out != 1)
	{
		pid = fork();
		if (pid == 0)
		{
			g_mini->exitflag = 1;
			if (!ft_open_reds(cmd))
				exit(-1);
			g_mini->return_code = ft_runbuiltin(cmd);
			ft_closepipes();
			exit(-1);
		}
		return (pid);
	}
	if (!ft_open_reds(cmd))
		return (-1);
	g_mini->return_code = ft_runbuiltin(cmd);
	return (-1);
}
