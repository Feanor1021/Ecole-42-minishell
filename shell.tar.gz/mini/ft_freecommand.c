/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_freecommand.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:07:28 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:07:31 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include "minishell.h"

void	ft_freecommand(t_command *cmd)
{
	if (cmd)
	{
		if (cmd->out != 1)
			close(cmd->out);
		if (cmd->in != 0)
			close(cmd->in);
		ft_freearr_str(cmd->arguments);
		ft_freearr_str(cmd->heredocsteps);
		ft_freearr((void **)cmd->redirections, (void (*)(void *))ft_freestream);
		free(cmd->command);
		free(cmd);
	}
}
