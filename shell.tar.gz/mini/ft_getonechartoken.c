/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_getonechartoken.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:09:05 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:09:07 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "minishell.h"
#include "42-Libft/libft.h"

t_token	*ft_getonechartoken(enum e_tokentype type, int *i, char chr)
{
	char	schr[2];

	(*i)++;
	schr[0] = chr;
	schr[1] = 0;
	return (ft_createtoken(ft_strdup(schr), type));
}
