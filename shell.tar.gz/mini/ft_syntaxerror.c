/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_syntaxerror.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:15:40 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:15:43 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

void	ft_syntaxerror(t_token *token)
{
	if (token)
	{
		ft_putstr_fd("bash: sytax error near unexpected token `", 2);
		ft_putstr_fd(token->data, 2);
		ft_putstr_fd("'\n", 2);
	}
	else
		ft_putstr_fd("bash: sytax error near unexpected token `newline'", 2);
	g_mini->return_code = 258;
}
