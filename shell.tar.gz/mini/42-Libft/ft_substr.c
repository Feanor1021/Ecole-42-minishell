/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 21:05:09 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 22:14:44 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	char	*dest;
	size_t	index;

	if (!s)
		return (NULL);
	if (ft_strlen(s) < len)
		len = ft_strlen(s);
	if (start >= ft_strlen(s))
		return (ft_strdup(""));
	dest = (char *)malloc(sizeof(*s) * (len + 1));
	if (!dest)
		return (NULL);
	if (start >= ft_strlen(s))
		return (ft_strdup(""));
	index = 0;
	while (len--)
		dest[index++] = s[start++];
	dest[index] = '\0';
	return (dest);
}

/*
int main()
{
	printf("%s", ft_substr("Esra Eren Akbulut", 6, 6));
	printf("%d", substr("Esra Eren Akbulut", 6, 6));
	return (0);
}
*/
