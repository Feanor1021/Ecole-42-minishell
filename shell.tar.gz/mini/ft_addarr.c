/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_addarr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:03:30 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:03:34 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

void	ft_addarr(void ***arr, void *new)
{
	void	**ret;
	int		i;
	int		k;

	ret = ft_calloc(sizeof(void *), ft_arrlen((void **)*arr) + 2);
	k = 0;
	i = 0;
	while (*arr && (*arr)[k])
		ret[i++] = (*arr)[k++];
	ret[i] = new;
	free(*arr);
	*arr = ret;
}
