/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_getnexttoken.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:08:56 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 21:07:02 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

static t_token	*onechartoken(char *str, int *i)
{
	if (str[*i] == '>' && str[*i + 1] == '>')
		return (ft_gettwochartoken(str, i, RED_APPEND, '>'));
	else if (str[*i] == '<' && str[*i + 1] == '<')
		return (ft_gettwochartoken(str, i, HEREDOC, '<'));
	else if (str[*i] == '|')
		return (ft_getonechartoken(PIPE, i, '|'));
	else if (str[*i] == '>')
		return (ft_getonechartoken(RED_CREATE, i, '>'));
	else if (str[*i] == '<')
		return (ft_getonechartoken(RED_INPUT, i, '<'));
	return (NULL);
}

t_token	*ft_getnexttoken(char *str)
{
	static int	i = 0;
	t_token		*token;

	token = NULL;
	while (str[i])
	{
		token = onechartoken(str, &i);
		if (token)
			break ;
		if (!ft_isdelimitter(str[i]))
			return (ft_getwordtoken(str, &i));
		else
			i++;
	}
	if (token)
		return (token);
	i = 0;
	return (NULL);
}
