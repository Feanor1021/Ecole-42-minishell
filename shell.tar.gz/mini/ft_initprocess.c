/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_initprocess.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:09:50 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:10:02 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "minishell.h"
#include "42-Libft/libft.h"

int	ft_initprocess(t_command *cmd, char *cmdpath)
{
	pid_t	pid;
	int		execreturn;

	pid = fork();
	if (pid == 0)
	{
		ft_clearsignals();
		if (!ft_open_reds(cmd))
		{
			g_mini->exitflag = 1;
			exit(-1);
		}
		ft_connectio(cmd);
		ft_closepipes();
		execreturn = execve(cmdpath, cmd->arguments, g_mini->env);
		if (execreturn != 0)
		{
			ft_puterrno_msg(cmd->command);
			g_mini->exitflag = 1;
			exit(-1);
		}
	}
	return (pid);
}
