/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_create_prompt.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:05:18 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:05:25 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "42-Libft/libft.h"

char	*ft_create_prompt(void)
{
	char		*prompt;

	prompt = ft_strdup("minishell$>");
	return (prompt);
}
