/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_quote_utils.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:12:10 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:12:13 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_get_end_numbers_dbquotes(char *s, int *end)
{
	int	index;

	index = -1;
	*end = -1;
	while (++index || 1)
	{
		(*end)++;
		if (s[index] == '"' || !s[index])
			return ;
	}
}

void	ft_get_end_numbers_quote(char *s, int *end)
{
	int	index;

	index = -1;
	*end = -1;
	while (++index || 1)
	{
		(*end)++;
		if (s[index] == '\'' || !s[index])
			return ;
	}
}

void	ft_get_len_of_word(char *s, int *end)
{
	int	index;

	index = -1;
	*end = 0;
	while (s[++index] && !(s[index] == '"' || s[index] == '\''))
		(*end)++;
}
