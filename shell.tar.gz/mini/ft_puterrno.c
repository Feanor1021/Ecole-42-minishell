/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_puterrno.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:13:47 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:13:49 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <errno.h>
#include <string.h>
#include "minishell.h"
#include "42-Libft/libft.h"

void	ft_puterrno(void)
{
	char	*msg;

	msg = strerror(errno);
	ft_putstr_fd(msg, 2);
}
