/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parsewordtoken.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:13:25 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:13:27 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

int	ft_parsewordtoken(t_command *cmd, t_token **tokens, int i)
{
	if (!cmd->command)
		cmd->command = ft_strdup(tokens[i]->data);
	ft_addarr_str(&(cmd->arguments), ft_strdup(tokens[i]->data));
	return (1);
}
