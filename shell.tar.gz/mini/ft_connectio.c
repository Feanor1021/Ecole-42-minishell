/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_connectio.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:04:14 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:04:17 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include "minishell.h"

void	ft_connectio(t_command *cmd)
{
	if (cmd->out != 1)
	{
		dup2(cmd->out, 1);
		close(cmd->out);
		cmd->out = 1;
	}
	if (cmd->in != 0)
	{
		dup2(cmd->in, 0);
		close(cmd->in);
		cmd->in = 0;
	}
}
