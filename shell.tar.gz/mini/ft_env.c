/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_env.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:05:54 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:05:56 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

int	ft_env(t_command *command)
{
	int	i;

	i = -1;
	while (g_mini->env[++i])
		if (ft_strchr(g_mini->env[i], '='))
			ft_putendl_fd(g_mini->env[i], command->out);
	return (0);
}
