/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:16:30 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 21:56:21 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include "minishell.h"
#include "42-Libft/libft.h"

t_mini	*g_mini;

static void	init_g_mini(char **env)
{
	g_mini = ft_calloc(sizeof(t_mini), 1);
	g_mini->env = ft_copyarr_str(env);
}

static void	miniloop(void)
{
	char		*input;

	while (!g_mini->exitflag)
	{
		input = ft_getinput();
		if (!input)
		{
			write(1, "exit\n", 5);
			break ;
		}
		ft_execline(input);
		free(input);
	}
}

int	main(int ac, char **av, char **env)
{
	int		exitcode;

	(void)av;
	init_g_mini(env);
	ft_connectsignals();
	if (ac == 1)
		miniloop();
	exitcode = g_mini->return_code;
	ft_freearr_str(g_mini->env);
	free(g_mini);
	return (exitcode);
}
