/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parsecommand.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:12:27 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 21:07:46 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

static void	*erroroccured(t_command *cmd)
{
	ft_freecommand(cmd);
	return (NULL);
}

static t_command	*createcommand(void)
{
	t_command	*cmd;

	cmd = ft_calloc(sizeof(t_command), 1);
	cmd->in = 0;
	cmd->out = 1;
	return (cmd);
}

int	parsetoken(t_token **tokens, int *start, int end, t_command *cmd)
{
	if (*start < end && tokens[*start]->type == WORD && \
			!ft_parsewordtoken(cmd, tokens, *start))
		return (0);
	else if (*start < end && tokens[*start]->type == HEREDOC && \
			!ft_parseheredoc(cmd, tokens, start))
		return (0);
	else if (*start < end && tokens[*start]->type == RED_INPUT && \
			!ft_parseredinput(cmd, tokens, start))
		return (0);
	else if (*start < end && \
			(tokens[*start]->type == RED_CREATE || \
			tokens[*start]->type == RED_APPEND))
		if (!ft_parseredoutput(cmd, tokens, start))
			return (0);
	return (1);
}

t_command	*ft_parsecommand(t_token **tokens, int start, int end)
{
	t_command	*cmd;

	cmd = createcommand();
	while (tokens[start] && start < end)
	{	
		if (!parsetoken(tokens, &start, end, cmd))
			return (erroroccured(cmd));
		start++;
	}
	return (cmd);
}
