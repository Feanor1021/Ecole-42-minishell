/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_unset.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:16:01 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:16:04 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

int	ft_unset(t_command *command)
{
	int	i;

	i = 0;
	while (command->arguments[++i])
	{
		if (ft_env_check(command->arguments[i]))
			ft_delenv(command->arguments[i]);
		else
		{
			ft_putstr_fd("bash: unset: '", 2);
			ft_putstr_fd(command->arguments[i], 2);
			ft_putendl_fd("':not a valid identifier", 2);
		}
	}
	return (0);
}
