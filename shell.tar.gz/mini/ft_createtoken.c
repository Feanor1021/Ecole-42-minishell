/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_createtoken.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:05:28 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:05:31 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

t_token	*ft_createtoken(char *data, enum e_tokentype type)
{
	t_token	*token;

	token = ft_calloc(sizeof(t_token), 1);
	token->data = data;
	token->type = type;
	return (token);
}
