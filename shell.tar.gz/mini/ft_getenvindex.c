/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_getenvindex.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:08:16 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 20:08:19 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"
#include "42-Libft/libft.h"

int	ft_getenvindex(char *name)
{
	int		i;
	int		k;
	int		index;
	char	**env;

	if (name[0] == '$')
		name++;
	index = 0;
	env = g_mini->env;
	while (env[index])
	{
		i = 0;
		k = 0;
		while (env[index][i] && env[index][i] == name[k])
		{
			i++;
			k++;
		}
		if ((!name[k] && env[index][i] == '=') || !env[index][i])
			return (index);
		index++;
	}
	return (-1);
}
