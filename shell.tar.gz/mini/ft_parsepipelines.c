/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parsepipelines.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebudak <ebudak@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/01 20:12:54 by ebudak            #+#    #+#             */
/*   Updated: 2022/12/01 21:08:02 by ebudak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "minishell.h"
#include "42-Libft/libft.h"

static void	*erroroccured(t_pipeline **pipes, t_token *token)
{
	ft_freearr_pipeline(pipes);
	if (token)
		ft_syntaxerror(token);
	return (NULL);
}

static t_pipeline	*parsepipeline(t_token **tokens, int start, int end)
{
	t_pipeline	*ret;

	if (((char)tokens[0]->data[0] == '|' ))
	{
		ft_syntaxerror(*tokens);
		return (NULL);
	}
	ret = ft_calloc(sizeof(t_pipeline), 1);
	ret->commands = ft_parsecommands(tokens, start, end);
	if (!ret->commands)
	{
		ft_freearr_command(ret->commands);
		free(ret);
		return (NULL);
	}
	return (ret);
}

static int	findend(t_token **tokens, int start, int end)
{
	while (start < end && tokens[start])
		start++;
	return (start);
}

t_pipeline	**ft_parsepipelines(t_token **tokens, int start, int end)
{
	t_pipeline	*pipeline;
	t_pipeline	**pipes;
	int			i;

	pipes = NULL;
	i = start;
	while (i < end)
	{
		i = findend(tokens, i, end);
		pipeline = parsepipeline(tokens, start, i);
		if (tokens[i])
			if (!tokens[++i])
				return (erroroccured(pipes, tokens[i - 1]));
		if (!pipeline)
			return (erroroccured(pipes, NULL));
		ft_addarr_pipeline(&pipes, pipeline);
		start = i - 1;
	}
	return (pipes);
}
